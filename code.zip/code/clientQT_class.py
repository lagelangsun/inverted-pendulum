from PyQt5 import QtCore
from PyQt5.QtWidgets import QApplication, QMainWindow, QInputDialog, QMessageBox
from model_MainWindow import Ui_MainWindow
from ruler import RulerWidget
from visualise import ModelVisualise
from modelplot import Image
from control_class import controlclass
from param_class import param
from flag_class import flag_signal
from math import sin,cos,pi,sqrt
import sys, socket
import struct 
import pickle
import numpy as np
import time

class QTinterfaceclass(QMainWindow, Ui_MainWindow):
    
    def __init__(self, client_socket):   
        super().__init__()
        self.socket = client_socket              #client
        #flag/signal
        self.flag_signal_ = flag_signal()

        #初始化部分结束
        self.setupUi(self)
        self.receivedata = receivedataclass(self.socket,self.flag_signal_) #创建子线程的类
        self.ruler = RulerWidget()                                         #小车轨道坐标
        self.model_visual = ModelVisualise()                               #可视化小车和坐标
        self.model_plot = Image()                                       #更新曲线图
        self.verticalLayout_ruler.addWidget(self.ruler)                    
        self.verticalLayout_visual.addWidget(self.model_visual)
        self.verticalLayout_figure.addWidget(self.model_plot)
        
        
        self.control = controlclass()                                      #控制器

        #设置label
        
        self.posi_target = 0                                               #位移目标值
        targe_val_text = '位置目标值: {:.2f}'.format(self.posi_target)      
        self.label_target_val.setText(targe_val_text)                      #位移目标值显示
        self.label_figure_ok.setText('')                                   #模型波形图像更新显示框初始化时不显示
        self.label_figure_ok_printed = False                               #判断波形图是否需要更新
        
        #设置K矩阵
        self.label_K1.setText('K1: {:.2f}'.format(self.control.K[0]))
        self.label_K2.setText('K2: {:.2f}'.format(self.control.K[1]))
        self.label_K3.setText('K3: {:.2f}'.format(self.control.K[2]))
        self.label_K4.setText('K4: {:.2f}'.format(self.control.K[3]))

        #设置起摆最大加速度
        self.label_max_g.setText('起摆加速度限制: {:.1f}'.format(self.control.n))

        

        # 信号连接#信号开始连接开始，信号结束连接结束，接收到服务端发出的数据触发更新函数，接收到终止信号触发终止函数
        self.receivedata.received_signal.connect(self.get_control)              #收到信号时pyqt内置emit()函数触发get_control函数
        self.receivedata.terminate_signal.connect(self.receivedata.socket_stop) #同理，触发receivedata.socket_stop

        #设置按钮
        self.StartButton.clicked.connect(self.__pushbutton_successfully)     #开始按钮
        self.StopButton.clicked.connect(self.__pushbutton_successfully)      #停止按钮
        self.RecoveryButton.clicked.connect(self.__pushbutton_successfully)  #复原按钮
        self.ContinueButton.clicked.connect(self.__pushbutton_successfully)  #继续按钮
        self.ConnectionButton.clicked.connect(self.__pushbutton_successfully)#链接按钮
        self.K1.clicked.connect(self.__pushbutton_successfully)              #修改K1按钮
        self.K2.clicked.connect(self.__pushbutton_successfully)              #修改K2按钮
        self.K3.clicked.connect(self.__pushbutton_successfully)              #修改K3按钮
        self.K4.clicked.connect(self.__pushbutton_successfully)              #修改K4按钮
        self.TargetButton.clicked.connect(self.__pushbutton_successfully)    #修改目标位移按钮
        self.ConnectA.clicked.connect(self.__pushbutton_successfully)        #修改起摆最大加速度限制按钮

        #与服务端建立连接时设置
        self.connect_successfully = False
        self.IP = ''                     #IP地址
        self.port = 1024                 #端口号

        #测试用
        self.start_test = 0

    #处理按钮按下的函数
    def __pushbutton_successfully(self):
        sender = self.sender()               #QT内置的接收按钮按下的函数
        if sender == self.ConnectionButton:
            if not self.connect_successfully:           #第一次按下的时候connect_successfully是false，所以要先设置这些
                host = '127.0.0.1' 
                text, okpressed = QInputDialog.getText(self, '设置IP地址',    #按下按钮弹出来的第一个窗口
                                                '请输入IP地址或主机名', text=host)
                if okpressed:  # 2                 
                    self.IP = text                           #设置完IP地址确定后弹出来第二个窗口
                    text, okpressed = QInputDialog.getInt(self, '设置端口号',
                                                   '请输入端口号', min=1024)
                    if okpressed:  # 3
                        self.port = text
                        self.__server_connect()                       #与客户端建立连接，这个函数定义在这个类里，会把connect_successfully置位true
                        self.flag_signal_.c_connect_flag = True
                        print('已经连接成功')

            else:  # 2-
                QMessageBox.information(self, '提示', '已连接到 ' \
                                        + self.IP + ':' + str(self.port))

        elif sender == self.StartButton:  ###这个地方要发送一个信号过去，这里可能会处问题，要小心
            if not self.flag_signal_.c_connect_flag:       ###弹出一个界面
                QMessageBox.information(self, 'Warning', '请先进行连接')
            elif not self.flag_signal_.c_start_flag:    
                start_flag_signal_pack = struct.pack("cf",self.flag_signal_.begin_label,self.flag_signal_.c_start_signal)  #####
                self.socket.send(start_flag_signal_pack)            #发送带有数据标志的数据
                self.flag_signal_.c_start_flag = True               #按下开始把所有按键置为默认
                self.flag_signal_.c_stop_flag = False
                self.flag_signal_.c_recovery_flag = False
                self.flag_signal_.c_continue_flag = False
                self.flag_signal_.swing_stable_flag = False
                self.start_test = 1

        elif sender == self.RecoveryButton:  ##################这个地方要发送一个信号过去，这里可能会处问题，要小心
            if not self.flag_signal_.c_stop_flag:       #################弹出一个界面
                QMessageBox.information(self, 'Warning', '请先暂停程序')
            elif not self.flag_signal_.c_recovery_flag:   #我按下他  
                recovery_flag_signal_pack = struct.pack("cf",self.flag_signal_.recovery_label,self.flag_signal_.c_recovery_signal)  ###################################
                self.socket.send(recovery_flag_signal_pack)
                self.flag_signal_.c_recovery_flag = True
                self.flag_signal_.c_start_flag = False      #按下恢复的时候就可以再按开始了
                

        elif sender == self.StopButton:  
            if not self.flag_signal_.c_start_flag:        #必须得运行的时候才能停止
                QMessageBox.information(self, 'Warning', '程序没有在运行')
            elif not self.flag_signal_.c_stop_flag:      #如果不在暂停状态的话  
                stop_flag_signal_pack = struct.pack("cf",self.flag_signal_.stop_label,self.flag_signal_.c_stop_signal)  ###################################
                self.socket.send(stop_flag_signal_pack)
                self.flag_signal_.c_stop_flag = True
                self.flag_signal_.c_recovery_flag = False
                self.flag_signal_.c_continue_flag = False


        elif sender == self.ContinueButton:  ##################这个地方要发送一个信号过去，这里可能会处问题，要小心
            if not self.flag_signal_.c_stop_flag:       #################弹出一个界面
                QMessageBox.information(self, 'Warning', '程序没有暂停')
            elif not self.flag_signal_.c_continue_flag:   #我按下他  
                continue_flag_signal_pack = struct.pack("cf",self.flag_signal_.continue_label,self.flag_signal_.c_continue_signal)  ###################################
                self.socket.send(continue_flag_signal_pack)
                self.flag_signal_.c_continue_flag = True
                self.flag_signal_.c_stop_flag = False     #点了继续之后就又可以暂停了


        elif sender == self.TargetButton:                #目标位移值            
            text_target, okpressed = QInputDialog.getDouble(self, '设置目标值', '请输入目标值',
                                              min=-8, max=8, decimals=2)
            if okpressed:
                self.control.x_place = float(text_target)
                self.posi_target = text_target
                self.label_figure_ok.setText('') #更改文本框的显示
                self.label_figure_ok_printed = False

        elif sender == self.K1:  # 33
            text_k1, okpressed = QInputDialog.getDouble(self, '设置参数一', '请输入参数一',
                                              min=-500, max=500, decimals=2)
            if okpressed:
                self.control.K[0] = float(text_k1)
                self.label_K1.setText('K1: {:.2f}'.format(self.control.K[0]))  #更改文本框的显示

        elif sender == self.K2:  # 33
            text_k2, okpressed = QInputDialog.getDouble(self, '设置参数二', '请输入参数二',
                                              min=-1000, max=1000, decimals=2)
            if okpressed:
                self.control.K[1] = float(text_k2)
                self.label_K1.setText('K2: {:.2f}'.format(self.control.K[1]))


        elif sender == self.K3:  # 33
            text_k3, okpressed = QInputDialog.getDouble(self, '设置参数三', '请输入参数三',
                                              min=-1000, max=1000, decimals=2)
            if okpressed:
                self.control.K[2] = float(text_k3)
                self.label_K1.setText('K3: {:.2f}'.format(self.control.K[2]))

        elif sender == self.K4:  #33
            text_k4, okpressed = QInputDialog.getDouble(self, '设置参数四', '请输入参数四',
                                              min=-1000, max=1000, decimals=2)
            if okpressed:
                self.control.K[3] = float(text_k4) #改参数 
                self.label_K1.setText('K4: {:.2f}'.format(self.control.K[3]))

        elif sender == self.ConnectA:  #这个是起摆最大加速度n
            text_A, okpressed = QInputDialog.getDouble(self, '设置参数五', '请输入参数五',
                                              min=-1000, max=1000, decimals=2)
            if okpressed:
                self.control.n = float(text_A)  #改参数
                self.label_max_g.setText('起摆加速度限制: {:.1f}'.format(self.control.n))  

    def __server_connect(self):
        self.socket.connect((self.IP, self.port))     #就是socket那一套流程，self.socket = client,实例化之后与服务端建立连接(dataSocket.connect)
        self.connect_successfully = True
        self.receivedata.start()         #start的时候会自动执行receivedataclass类里面的run函数

    def get_control(self):
        #更新模型

        # 更新目标值显示
        targe_val_text = '位置目标值: {:.2f}'.format(self.posi_target)
        self.label_target_val.setText(targe_val_text)

        data = self.receivedata.receive_data                ##(self.receivedata = Statereciver(xx,xx,xx),实例化类)
        state = struct.unpack("<4f",data)                            ##等待修改


        F = self.__X_to_F(state,self.control)    
        F_pack = struct.pack("cf",self.flag_signal_.data_label,*[F])  #加标志
        if self.flag_signal_.c_start_flag and self.start_test:
            # print('按下开始发的F:',F)
            self.start_test = 0

        if not self.flag_signal_.c_recovery_flag:
            self.socket.send(F_pack)   #在这里发吧，把控制量发给服务端

        self.__nextdraw(state)  #更新一次图像

    # 更新倒立摆可视化模型 
    def __nextdraw(self,state):
        self.model_visual.set_value(state[2], state[0])
        self.ruler.set_value(state[2])

        self.model_plot.update_data(self.posi_target, state[0], state[2])
        if self.model_plot.is_painted and not self.label_figure_ok_printed:
            self.label_figure_ok.setText('倒立摆控制成功')
            self.label_figure_ok_printed = True

    #判断使用何种控制器
    def __X_to_F(self,state_0,control):                               
        if cos(state_0[0]) > cos(pi/8) or self.flag_signal_.swing_stable_flag:   #判断执行起摆还是稳摆算法
            F = self.control.LQRcal1(state_0)             #(LQR控制)转置进去，测试的时候要修改F[0],初始角度在-0.4~0.4之间，初始角加速度为0
            self.flag_signal_.swing_stable_flag = True
        else:
            F = self.control.swingcal(70,state_0)         #(swing控制)K_E n Xk
        return F

    #关闭窗口
    def closeEvent(self, event):
        reply = QMessageBox.question(self, '确认', '确认退出吗',
                    QMessageBox.Yes | QMessageBox.No, QMessageBox.No)

        if reply == QMessageBox.Yes:
            self.receivedata.terminate_signal.emit() #触发终止emit
            event.accept()
        else:
            event.ignore()


class receivedataclass(QtCore.QThread):  #继承QT内部的QtCore.QThread，可以开线程

    received_signal = QtCore.pyqtSignal()   #QT内置
    terminate_signal = QtCore.pyqtSignal()  

    def __init__(self,client_socket,flag_signal): #传进来的socket就是外面的self.socket = client
        super().__init__()
        self.socket = client_socket
        self.receive_data = 0
        self.flag = flag_signal

    def run(self):   #.start后自己调用(因为super,所以可以复写run把之前QThread里面的run覆盖)，一直循环等待接收那边发来的信息
        BUFLEN = 512
        while 1:
            self.receive_data = self.socket.recv(BUFLEN) #接收服务端发来的信息(一个状态变量)
            self.received_signal.emit()                  #接收到信息后触发emit
    
    #断开socket连接
    def socket_stop(self):

        exit_flag_signal_pack = struct.pack("cf",self.flag.exit_label,self.flag.exit_signal)
        self.socket.send(exit_flag_signal_pack)
        # print('我发送了?')"""  """
        time.sleep(0.1)                            #等退出信号先发过去
        self.socket.close()
        # time.sleep(1)
        self.terminate()                           #super查询的父类QtCore.QThread中的方法
        print('连接关闭')



