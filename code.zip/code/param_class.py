import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import math
from math import sin
from math import cos
from math import pi
from math import sqrt

class param(object):

    def __init__(self):

        ###基础变量#################
        self.car_m = 1             #小车质量
        self.pend_m = 1            #杆质量
        self.pend_2l = 0.6         #杆长
        self.pend_l = 0.3          #杆半长
        self.g = 10                #重力加速度 
        self.J = (1/3)*self.pend_m*math.pow(self.pend_l,2) #杆对质心的转动惯量

        #简化控制状态方程过程量(θ~-10° - 10°)
        self.den_equation = self.J*(self.car_m+self.pend_m)+self.car_m*self.pend_m*math.pow(self.pend_l,2)  #系统模型简化后分母
        self.equation_X_x = -self.g*math.pow(self.pend_m*self.pend_l,2)/self.den_equation
        self.equation_X_theta = (self.car_m+self.pend_m)*self.pend_m*self.pend_l*(self.g)/self.den_equation
        self.equation_F_x = (self.J+self.pend_m*math.pow(self.pend_l,2))/self.den_equation
        self.equation_F_theta = -self.pend_m*self.pend_l/self.den_equation

        #连续状态方程矩阵
        self.A = np.array([[0,1,0,0],[self.equation_X_theta,0,0,0],[0,0,0,1],[self.equation_X_x,0,0,0]])
        self.B = np.array([[0,self.equation_F_theta,0,self.equation_F_x]]).T
        self.sample_time = 0.005                 #采样时间