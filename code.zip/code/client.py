from PyQt5 import QtCore
from PyQt5.QtWidgets import QApplication, QMainWindow, QInputDialog, QMessageBox
from model_MainWindow import Ui_MainWindow
from ruler import RulerWidget
from visualise import ModelVisualise
from modelplot import Image
from control_class import controlclass
from param_class import param
from flag_class import flag_signal
from math import sin,cos,pi,sqrt
from clientQT_class import QTinterfaceclass
# import sys, socket
import sys
from socket import *
import struct
import pickle
import numpy as np
import time

if __name__ == '__main__':
    client = socket(AF_INET, SOCK_STREAM)  #实例化一个socket对象，指明协议
    app = QApplication(sys.argv)  #必须要有
    main_ui = QTinterfaceclass(client)   #client就是socket的实例化对象
    main_ui.show()
    sys.exit(app.exec_())