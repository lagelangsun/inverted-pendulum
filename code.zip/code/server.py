'''
Author: lagelangsun 2541566634@qq.com
Date: 2021-06-26 19:24:19
LastEditors: lagelangsun 2541566634@qq.com
LastEditTime: 2023-12-21 22:30:53
FilePath: \code\server.py
Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
'''
import time
import numpy as np
import pickle
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import math
import struct
from threading import Thread
from socket import *
from math import sin,cos,pi,sqrt,pi
from param_class import param
from flag_class import flag_signal
from model_class import modelclass
from server_class import serverclass
 

if __name__ == '__main__':

    server = serverclass(socket)

    #循环等待客户端连接
    while True:
        server.accept()     #调用accept，与客户端建立连接
        print("????")
        th = Thread(target=server.clientHandler,args=(server.dataSocket,server.addr)) # 创建新线程处理和这个客户端的消息收发
        th.start()
    listenSocket.close()

