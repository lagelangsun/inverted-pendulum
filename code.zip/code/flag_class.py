class flag_signal(object):
    def __init__(self):

        self.s_start_flag = False
        self.s_start_signal = 0

        self.s_shutdown_flag = False
        self.s_shutdown_signal = 0

        self.s_update_flag = False

        self.c_start_flag = False       #判断是否按下开始
        self.c_recovery_flag = False    #判断是否按下恢复
        self.c_stop_flag = False        #判断是否按下暂停
        self.c_continue_flag = False    #判断是否按下继续
        self.c_connect_flag = False     #判断是否有服务端建立了连接
        self.swing_stable_flag = False  #判断执行起摆算法还是稳摆算法
        
        self.data_label = 'd'.encode("utf-8")  #data,数据标志

        self.begin_label = 'b'.encode("utf-8") #begin，开始标志
        self.c_start_signal = 1

        self.stop_label = 's'.encode("utf-8")  #stop，暂停标志
        self.c_stop_signal = 1

        self.recovery_label = 'r'.encode("utf-8") #recovery，恢复标志
        self.c_recovery_signal = 1

        self.continue_label = 'c'.encode("utf-8") #continue，继续标志
        self.c_continue_signal = 1

        self.exit_label = 'e'.encode("utf-8") #exit，退出标志
        self.exit_signal = 1