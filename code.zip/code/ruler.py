from PyQt5.QtWidgets import QWidget
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPainter, QFont, QColor, QPen
import numpy as np

class RulerWidget(QWidget):

    def __init__(self):      
        super().__init__()
        self.max_length = 16
        self.carlength = 80 
        
        self.value = 0
        self.number = np.array([-8,-7,-6,-5,-4,-3,-2,-1,0,1,2,3,4,5,6,7,8])


    def paintEvent(self, e):

        qp = QPainter()
        qp.begin(self)

        qp.setFont(QFont('Serif', 20, QFont.SansSerif))
        size = self.size()
        Qwidth = size.width()
        Qheight = size.height()

        mid_width = int(Qwidth/2)

        position_gain = int((Qwidth-self.carlength) / self.max_length)

        qp.setPen(QColor(255, 255, 255))

        if self.value >= 0:
            x_middle = int(position_gain * self.value)
            x_position = x_middle

            qp.setBrush(QColor(255, 242, 204))
            qp.drawRect(mid_width, 0, x_position, Qheight)

        elif self.value < 0:
            x_middle = int(position_gain * abs(self.value))
            x_position =mid_width - x_middle

            qp.setBrush(QColor(255, 242, 204))
            qp.drawRect(x_position, 0,mid_width-x_position, Qheight) # x,y,w,h


        pen = QPen(QColor(20, 20, 20), 1, Qt.SolidLine)

        qp.setPen(pen)
        qp.setBrush(Qt.NoBrush)
        qp.drawRect(0, 0, Qwidth-1, Qheight-1)

        step = int((Qwidth-self.carlength) /16)

        j = 0
        for i in range(int(self.carlength/2), 17*step, step):
            qp.drawLine(i, 0, i, 5)
            metrics = qp.fontMetrics()
            fw = metrics.width(str(self.number[j]))
            qp.drawText(int(i-fw/2), int(Qheight/2), str(self.number[j]))
            j = j + 1


        qp.end()
    def set_value(self, value):
        self.value = value
        self.repaint()


