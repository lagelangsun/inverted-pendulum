import numpy as np
import matplotlib.pyplot as plt
from math import sin,pi,cos

# theta1
class modelclass(object):
    def __init__(self):
        self.state0 = np.array([pi,0,0,0]) #初始状态

    def transform (self,F,state,sampletime1):  #state = [theta1,thetadot1,car_place1,car_place_dot1]
        theta=state[0]
        thetadot=state[1]
        car_place=state[2]
        car_place_dot=state[3]
        sample_time =sampletime1
        F = F
        dt = sample_time

        theta_k_1 = thetadot
        sin_theta = sin(theta)
        cos_theta = cos(theta)
        num1 = 0.3 * cos_theta * F + 0.09 * sin_theta * cos_theta * theta_k_1** 2 - 5.88 * sin_theta
        den1 = 0.09 * cos_theta ** 2 - 0.24
        theta_l_1 = num1 / den1

        xplace_k1 = car_place_dot
        num2 = 0.036 * sin_theta *  theta_k_1 ** 2 + 0.12 * F - 0.8820 * sin_theta * cos_theta
        den2 = 0.24 - 0.09 * cos_theta ** 2
        xplace_l_1 = num2/den2

        theta_k_2 = thetadot + theta_l_1 * dt / 2
        xplace_k_2 = car_place_dot + xplace_l_1 * dt / 2


        sin_theta = sin(theta+theta_k_1*dt/2)
        cos_theta = cos(theta+theta_k_1*dt/2)
        num3 = 0.3 * cos_theta * F + 0.09 * sin_theta * cos_theta * theta_k_2 ** 2 - 5.88 * sin_theta
        den3 = 0.09 * cos_theta ** 2 - 0.24
        theta_l_2 =num3/den3

        num4 = 0.036 * sin_theta * theta_k_2** 2 + 0.12 * F - 0.8820 * sin_theta * cos_theta
        den4 = 0.24 - 0.09 * cos_theta ** 2
        xplace_l_2 = num4/den4


        theta_k_3 = thetadot + theta_l_2 * dt / 2
        xplace_k_3 = car_place_dot + xplace_l_2 * dt / 2

        sin_theta = sin(theta+theta_k_2*dt/2)
        cos_theta = cos(theta+theta_k_2*dt/2)
        num5 = 0.3 * cos_theta * F + 0.09 * sin_theta * cos_theta * theta_k_3 ** 2 - 5.88 * sin_theta
        den5 = 0.09 * cos_theta ** 2 - 0.24
        theta_l_3 = num5 / den5

        num6 = 0.036 * sin_theta * theta_k_3 ** 2 + 0.12 * F - 0.8820 * sin_theta * cos_theta
        den6 = 0.24 - 0.09 * cos_theta ** 2
        xplace_l_3 = num6/den6

        theta_k_4 = thetadot + theta_l_3 * dt
        xplace_k_4 = car_place_dot + xplace_l_3 * dt

        sin_theta = sin(theta+theta_k_3*dt)
        cos_theta = cos(theta+theta_k_3*dt)
        num7 = 0.3 * cos_theta * F + 0.09 * sin_theta * cos_theta * theta_k_4 ** 2 - 5.88 * sin_theta
        den7 = 0.09 * cos_theta ** 2 - 0.24
        theta_l_4 = num7/den7

        num8 = 0.036 * sin_theta * theta_k_4 ** 2 + 0.12 * F - 0.8820 * sin_theta * cos_theta
        den8 = 0.24 - 0.09 * cos_theta ** 2
        xplace_l_4 = num8/den8

        theta += (theta_k_1 + 2 * theta_k_2 + 2 * theta_k_3 + theta_k_4) * dt / 6
        thetadot += (theta_l_1 + 2 * theta_l_2 + 2 * theta_l_3 + theta_l_4) * dt / 6
        car_place += (xplace_k1 + 2 * xplace_k_2 + 2 * xplace_k_3 + xplace_k_4) * dt / 6
        car_place_dot += (xplace_l_1 + 2 * xplace_l_2 + 2 * xplace_l_3 + xplace_l_4) * dt / 6
        state = np.array([theta,thetadot,car_place,car_place_dot])

        if state[0] > 15*pi/8:  #################################################
            state[0] =  state[0] - 2*pi   
        return state


