class haha(object):
    def __init__(self):
        self.name = '1'
    def ha(self):
        self.__xixi()
    def __xixi(self):
        print("xuxu")

a = haha()
a.ha()