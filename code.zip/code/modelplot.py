import matplotlib
matplotlib.use("Qt5Agg")  # 声明使用QT5
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
import numpy as np

class Image(FigureCanvasQTAgg):

    def __init__(self, width=15, height=15, dpi=100):#######初始化
        self.fig = Figure(figsize=(width, height), dpi=dpi)
        super(Image,self).__init__(self.fig)
        self.max_num = 1000
        self.theta_precision_value = 0.01
        self.position_precision_value = 0.01
        self.Stabilization_time = 100
        self.stable_number = 0

        self.x_sequence = np.arange(1, self.max_num+1)
        self.target_array = np.zeros(self.max_num)
        self.position_array = np.zeros(self.max_num)
        self.theta_array = np.zeros(self.max_num)
        self.Countnum = 0
        self.stability = False
        self.is_painted = False

        self.position_target = 0
        self.theta_target = 0

        self.axes = self.fig.add_subplot(111)


    def update_data(self, position_target, theta, position): #目标量，角度量，位置量
        if self.position_target != position_target:
            self.position_target = position_target
            self.stability = False
            self.is_painted = False
            #self.Countnum = 0
            self.stable_number = 0

        if not self.stability: ###稳定性判断，判断是否稳定
            if self.Countnum < self.max_num:
                self.theta_array[self.Countnum] = theta
                self.position_array[self.Countnum] = position
                self.target_array[self.Countnum] = self.position_target######计数
                self.Countnum += 1

            elif self.Countnum == self.max_num:########迭代解决越线问题
                self.theta_array = np.roll(self.theta_array, -1)
                self.position_array = np.roll(self.position_array, -1)
                self.target_array = np.roll(self.target_array, -1)
                self.theta_array[-1] = theta
                self.position_array[-1] = position
                self.target_array[-1] = self.position_target
            
            else:
                print('缓冲区错误')

            if abs(position - self.position_target) < self.position_precision_value and \
                abs(theta - 0) < self.theta_precision_value:#######精度判断
                self.stable_number += 1
            else:
                self.stable_number = 0

            if self.stable_number >= self.Stabilization_time:#######精度数判断
                self.stability = True

        else:
            if not self.is_painted:
                self.axes.cla()##########画图细节补充
                self.axes.plot(self.x_sequence[:self.Countnum], self.theta_array[:self.Countnum],
                                label='theta')
                self.axes.plot(self.x_sequence[:self.Countnum], self.position_array[:self.Countnum],
                                label='position')
                self.axes.plot(self.x_sequence[:self.Countnum], self.target_array[:self.Countnum],
                                label='target')
                self.axes.legend()
                self.axes.grid()
                self.fig.canvas.draw()
                self.is_painted = True


















