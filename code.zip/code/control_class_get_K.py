import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import math
from math import sin,cos,pi,sqrt
from param_class import param      #封装的另一个类，用来存放可能用到的各种参数、系数

class controlclass_getk(object):
    
    def __init__(self):
        
        self.param_ = param()  #专门放可能用到的各种变量的类
        self.name = 'LQRcontrol'
        self.A = self.param_.A   #矩阵A
        self.B = self.param_.B   #矩阵B
        self.Q = np.array([[50,0,0,0],[0,10,0,0],[0,0,20,0],[0,0,0,10]]) #初始的Q
        self.R = 1         #初始R
        self.K = np.array([-62.6527,-11.2882,-4.4721,-6.9390])   #用MATLAB算出来的K
        self.n = 1         #
        self.x_place = 0   #目标小车位置
        
    #离散化矩阵A和B
    def __discreetAB(self,s_A,s_B,s_dt):
        
        I = np.identity(4)  
        Adiff = np.dot(np.linalg.inv(I-0.5*s_A*s_dt),I+0.5*s_A*s_dt)
        Bdiff = s_B*s_dt
        
        return Adiff,Bdiff
        
    #设置矩阵Q,R对角线系数
    def __LQR_setQR(self,Q,R):
        Q1 = np.zeros((4,4))
        Q1[0,0] = Q[0]
        Q1[1,1] = Q[1]
        Q1[2,2] = Q[2]
        Q1[3,3] = Q[3]
        self.Q = Q1
        self.R = R
        
    #获取修改Q和R后得到的新K
    def get_K(self,Q,R):
        self.__LQR_setQR(Q,R)
        Adiff,Bdiff = self.__discreetAB(self.A,self.B,self.param_.sample_time)
        maxiter1 = 2000
        threshold = 0.001
        P = self.Q
#         print(Adiff,'\n',Bdiff,'\n',P)
        K = np.zeros((1,4))
        
        for i in range(maxiter1):
            
            form1 = (Adiff.T)@P@Adiff
            form2 = (Adiff.T)@P@Bdiff
            form3 = (Bdiff.T)@P@Adiff
            invform = np.linalg.inv(self.R+(Bdiff.T)@P@Bdiff)
            P_next = self.Q + form1 - form2@invform@form3
            
            if (abs(P_next - P)).max()  < threshold: #迭代到P不再变化
                P = P_next
                break
            P = P_next
            
#       form4 = R+(Bdiff.T)@P@np.linalg.pinv(Bdiff).T
#       form4 = R+(Bdiff.T)@P@Bdiff
        form4 = np.linalg.inv(self.R+(Bdiff.T)@P@Bdiff)
        form5 = (Bdiff.T)@P@(Adiff)
        K = form4@form5
        return K[0]

    #更改K
    def cal_K(self,Q,R):
        self.K = self.get_K(Q,R)
    
    #测试函数，测试类中的各个函数和属性有没有错
    def testLQR(self,Q,R):

        print('执行测试函数:')
        KK = self.get_K([50,10,20,10],1)
        print('A:\n',self.A,'\nB:\n',self.B)
        print('Q:\n',self.Q,'\nR:\n',self.R)
        print('get_K函数得到的K',KK)
    
    
    #第一种使用LQR的方法：获取反馈作为控制量输入对象模型
    def LQRcal1(self,Xk_0):
        
        F = self.x_place*self.K[2] - np.dot(self.K,Xk_0)
        
        return F
    
    
    #第二种方法：迭代直接得到下一个状态量，跳过控制器与对象模型之间的通信
    def LQRcal2(self,Adiff,Bdiff,Xk_0):
        
        Xk_1 = Adiff@Xk_0 - Bdiff@self.K@Xk_0
        
        return Xk_1
    
    
    #起摆算法
    def swingcal(self,K_E,Xk):  
        
        theta = Xk[0]
        thetadot = Xk[1]
        
        Jp = self.param_.J + self.param_.pend_m*math.pow(self.param_.pend_l,2)
        E_G = 0.5*Jp*math.pow(thetadot,2)                             #计算势能
        E_K =  self.param_.pend_m*self.param_.g*self.param_.pend_l*(cos(theta)-1)          #计算动能
        E = E_G+E_K
        
        sign = np.sign(thetadot*cos(theta))     #sign[(θdot)cos(θ)]
        U = K_E * sign * (E-0)                  #根据控制公式计算下一次输入，E应为E-E0，E0设为0省略
        
        if abs(U) > self.n*self.param_.g:              #限制下次控制量大小
            U = np.sign(U)*self.n*self.param_.g
        
        return U