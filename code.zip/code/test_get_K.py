from control_class_get_K import controlclass_getk
import numpy as np

control = controlclass_getk()
print('matlab算出来的K',control.K)
control.testLQR([50,10,20,10],1)


