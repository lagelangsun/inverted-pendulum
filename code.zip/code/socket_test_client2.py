#曹  征
#开发时间：2021-06-03 16:27

# ===tcp 客户端程序 ====
#导入socket库
from socket import *

# 主机地址为0.0.0.0，表示绑定本机所有网络接口ip地址
#等待客户端来连接
IP = '127.0.0.1'
#端口号
SERVER_PORT=50000
#定义一次从socket缓冲区最多读入512个字节数据
BUFLEN = 512

#实例化一个socket对象，指明协议
dataSocket = socket(AF_INET,SOCK_STREAM)

#链接服务端socket
dataSocket.connect((IP,SERVER_PORT))

while True:
#从终端读入用户输入的字符串

    toSend = input('>> ')
    #struct.pack
    if toSend =='exit':
        break
    dataSocket.send(toSend.encode())    #发送消息，也要编码为bytes

    #等待接收服务锻信息
    recved = dataSocket.recv(BUFLEN)

    #如果返回空bytes，表示对方关闭了链接
    if not recved:
         break
    #打印读取的信息
    print(recved.decode())
dataSocket.close()

