from control_class import controlclass
import numpy as np

con = controlclass()

con.LQR_setQR([60,10,40,10],1)
K = con.discreet_LQR_get_K()
print(K)