import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import math
from math import sin
from math import cos
from math import pi
from math import sqrt
from param_class import param

class controlclass(object):
    
    def __init__(self):
        
        self.param_ = param()
        self.name = 'LQRcontrol'
        self.A = self.param_.A  #A矩阵
        self.B = self.param_.B  #B矩阵
        self.Q = np.zeros((4,4))  
        self.R = 0

        self.K = np.array([-62.6527,-11.2882,-4.4721,-6.9390])
        self.n = 1      #起摆过程最大加速度限制
        self.x_place = 0  #目标位置
        
    def __discreetAB(self,s_A,s_B,s_dt):  #离散化函数
        
        I = np.identity(4)  
        Adiff = np.dot(np.linalg.inv(I-0.5*s_A*s_dt),I+0.5*s_A*s_dt)
        Bdiff = s_B*s_dt
        
        return Adiff,Bdiff
        
        
    #设置矩阵Q,R对角线系数
    def LQR_setQR(self,Q,R):
        Q1 = np.zeros((4,4))
        Q1[0,0] = Q[0]
        Q1[1,1] = Q[1]
        Q1[2,2] = Q[2]
        Q1[3,3] = Q[3]
        self.Q = Q1
        self.R = R
        
        
    #获取离散化LQR反馈增益K
    def get_K(self):
        
        Adiff,Bdiff = self.__discreetAB(self.A,self.B,self.param_.sample_time)
        maxiter1 = 2000
        threshold = 0.001
        P = self.Q
#         print(Adiff,'\n',Bdiff,'\n',P)
        K = np.zeros((1,4))
        
        for i in range(maxiter1):
            
            form1 = (Adiff.T)@P@Adiff
            form2 = (Adiff.T)@P@Bdiff
            form3 = (Bdiff.T)@P@Adiff
            invform = np.linalg.inv(self.R+(Bdiff.T)@P@Bdiff)
            P_next = self.Q + form1 - form2@invform@form3
            
            if (abs(P_next - P)).max()  < threshold: #迭代到P不再变化
                P = P_next
                break
            P = P_next
            
#       form4 = R+(Bdiff.T)@P@np.linalg.pinv(Bdiff).T
#       form4 = R+(Bdiff.T)@P@Bdiff
        form4 = np.linalg.inv(self.R+(Bdiff.T)@P@Bdiff)
        form5 = (Bdiff.T)@P@(Adiff)
        K = form4@form5
        
        # return K[0]
        return K[0]

    def cal_K():
        self.K = self.get_K()
    
    #测试函数
    def testLQR(self):
        
        print('A,B:')
        print(self.A,'\n',self.B,'\n')
        print('Adiff,Bdiff:')
        print(self.Adiff,'\n',self.Bdiff,'\n')
        [Q,R] = self.LQR_setQR([80,10,40,10],1)
        print('Q R:')
        print(Q,'\n',R,'\n')
        K = self.discreet_LQR_get_K()
        print('\n返回K',K)
    
    
    #第一种使用LQR的方法：获取反馈作为控制量输入对象模型
    def LQRcal1(self,Xk_0):
        
        F = self.x_place*self.K[2] - np.dot(self.K,Xk_0)
        
        return F
    
    
    #第二种方法：迭代直接得到下一个状态量，跳过控制器与对象模型之间的通信
    def __LQRcal2(self,Adiff,Bdiff,Xk_0):
        
        Xk_1 = Adiff@Xk_0 - Bdiff@self.K@Xk_0
        
        return Xk_1
    
    
    #起摆算法
    def swingcal(self,K_E,Xk):  
        
        theta = Xk[0]
        thetadot = Xk[1]
        
        Jp = self.param_.J + self.param_.pend_m*math.pow(self.param_.pend_l,2)
        E_G = 0.5*Jp*math.pow(thetadot,2)                             #计算势能
        E_K =  self.param_.pend_m*self.param_.g*self.param_.pend_l*(cos(theta)-1)          #计算动能
        E = E_G+E_K
        
        sign = np.sign(thetadot*cos(theta))     #sign[(θdot)cos(θ)]
        U = K_E * sign * (E-0)                  #根据控制公式计算下一次输入，E应为E-E0，E0设为0省略
        
        if abs(U) > self.n*self.param_.g:              #限制下次控制量大小
            U = np.sign(U)*self.n*self.param_.g
        
        return U