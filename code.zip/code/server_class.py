import time
import numpy as np
import pickle
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import math
import struct
from threading import Thread
from socket import *
from math import sin,cos,pi,sqrt,pi
from param_class import param
from flag_class import flag_signal
from model_class import modelclass

class serverclass(object):
    def __init__(self,socket):
        self.IP = '127.0.0.1'  #IP地址
        self.PORT = 1024       #端口号
        self.dataSocket = ''   #等待接收后赋值
        self.addr = ''         #等待接收后赋值
        self.listenSocket = socket(AF_INET, SOCK_STREAM) # 实例化一个socket对象 用来监听客户端连接请求，并指定协议
        self.listenSocket.bind((self.IP, self.PORT))  #连接
        self.listenSocket.listen(8)          #最多允许有八个客户端
        self.__start_successfully(self.PORT)   #开启成功提示

    def accept(self):
        self.dataSocket, self.addr = self.listenSocket.accept() # 返回一个套接字，即self.dataSocket
        addr = str(self.addr)
        print(f'一个客户端 {addr} 连接成功' )

    def __start_successfully(self,PORT):
        print(f'服务端启动成功，在{PORT}端口等待客户端连接...')

    def clientHandler(self,dataSocket,addr):
        model = modelclass()
        param_ = param()
        flag_sig = flag_signal()
        BUFLEN = 512
        recoverytest = 0 

        while True:

            infor_rec_pack = dataSocket.recv(BUFLEN) #接收客户端发送的数据，会阻塞线程
            judge,detail = self.__receive(infor_rec_pack)  #处理接收到的数据的函数，判断数据类型
            if judge == 'd' and flag_sig.s_start_flag:
                F_ = detail
                state_1 = model.transform(F_,model.state0,param_.sample_time)
                model.state0 = state_1   #更新内部实例化的属性state
                dataSocket.send(struct.pack("<4f",*state_1))      #给客户端的控制器发送状态量

            else:
                if judge == 'b':  #判断为开始
                    flag_sig.s_start_flag = True
                    model.state0 = np.array([pi,0,0,0])
                    dataSocket.send(struct.pack("<4f",*model.state0))
                    # print('我开始后先发送:',model.state0)
                if judge == 'c':  #判断为继续
                    flag_sig.s_start_flag = True
                    dataSocket.send(struct.pack("<4f",*model.state0))
                elif judge == 's':  #判断为停止
                    flag_sig.s_start_flag = False
                elif judge == 'r':  #判断为恢复
                    flag_sig.s_start_flag = False
                    model.state0 = np.array([pi,0,0,0])
                    # print('我要传送：',model.state0)
                    dataSocket.send(struct.pack("<4f",*model.state0))
                    recoverytest = 1
                elif judge == 'e': #判断为退出
                    print(f'客户端 {addr} 退出')
                    break
        dataSocket.close()

    def __receive(self,infor_rec_pack):
     
        infor_rec = struct.unpack("cf",infor_rec_pack)
        infor_rec_typejudge = infor_rec[0].decode("utf-8") #数据标志
        infor_rec_detail = infor_rec[1]  #具体数据内容
        # if infor_rec_typejudge == 'e':
        #     print('我收到了什么没:',infor_rec_typejudge)
        return infor_rec_typejudge,infor_rec_detail
        

